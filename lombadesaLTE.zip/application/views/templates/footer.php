      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark" style="display: none;">
          <!-- Control sidebar content goes here -->
          <div class="p-3">
              <h5>Title</h5>
              <p>Sidebar content</p>
          </div>
      </aside>
      <!-- /.control-sidebar -->

      <!-- Main Footer -->
      <footer class="main-footer text-center">
          <!-- To the right -->
          <div class="float-right d-none d-sm-inline">
              Anything you want
          </div>
          <!-- Default to the left -->
          <strong>Copyright © Muhamad Sholikhudin 2020 </strong> All rights reserved.
      </footer>
    </div>

      <!-- REQUIRED SCRIPTS -->

      <!-- jQuery -->
      <script src="<?= base_url('assets/'); ?>plugins/jquery/jquery.min.js"></script>
      <!-- Bootstrap 4 -->
      <script src="<?= base_url('assets/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- AdminLTE App -->
      <script src="<?= base_url('assets/'); ?>dist/js/adminlte.min.js"></script>


      </body>

      </html>